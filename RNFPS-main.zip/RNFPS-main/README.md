# RECURRENT-NEURO-FUZZY-PARALLEL-SYSTEM
It aims to predict stock market movements by using neural networks and fuzzy logic to understand the decision-making process.
